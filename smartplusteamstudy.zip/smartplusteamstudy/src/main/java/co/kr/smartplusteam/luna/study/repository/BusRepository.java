package co.kr.smartplusteam.luna.study.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import co.kr.smartplusteam.luna.study.vo.MyAndongBus;

//mysql에 staionId 와 regdate를 저장한다
@Repository
public interface BusRepository extends JpaRepository<MyAndongBus, String> {

}
