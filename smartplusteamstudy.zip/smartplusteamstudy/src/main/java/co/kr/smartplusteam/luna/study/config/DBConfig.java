package co.kr.smartplusteam.luna.study.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
@EnableJpaRepositories(basePackages = "co.kr.smartplusteam.luna.study.repository", entityManagerFactoryRef = "andongEntityManager", transactionManagerRef = "andongTransactionManager")
public class DBConfig {
	@Autowired
	private Environment env;

	private static final String prefix = "spring.andong.datasource.";

	@Bean(name = "andongEntityManager")
	// @Primary
	public LocalContainerEntityManagerFactoryBean andongEntityManager() {
		// log.info("LocalContainerEntityManagerFactoryBean");
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(dbMallDataSource());
		em.setPackagesToScan(new String[] { "co.kr.smartplusteam.luna.study.vo" });

		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);

		Map<String, Object> jpaProperties = new HashMap<>();
		em.setJpaPropertyMap(jpaProperties);
		return em;
	}

	@Bean(name = "andongTransactionManager")
	// @Primary
	public PlatformTransactionManager dbMallTransactionManager() {
		// log.info("dbMallTransactionManager");

		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(andongEntityManager().getObject());

		return transactionManager;
	}

	@Bean(name = "hikari")
	// @Bean
	// @Primary
	public HikariDataSource dbMallDataSource() {
		// log.info("dbMallDataSource");

		HikariConfig config = new HikariConfig();

		config.setJdbcUrl(env.getProperty(prefix + "url"));
		config.setUsername(env.getProperty(prefix + "username"));
		config.setPassword(env.getProperty(prefix + "password"));
		config.setMaxLifetime(Long.parseLong(env.getProperty(prefix + "hikari.max-lifetime")));
		config.setConnectionTimeout(Long.parseLong(env.getProperty(prefix + "hikari.connection-timeout")));
		config.setValidationTimeout(Long.parseLong(env.getProperty(prefix + "hikari.validation-timeout")));
		config.addDataSourceProperty("cachePrepStmts", env.getProperty(prefix + "hikari.data-source-properties.cachePrepStmts"));
		config.addDataSourceProperty("prepStmtCacheSize", env.getProperty(prefix + "hikari.data-source-properties.prepStmtCacheSize"));
		config.addDataSourceProperty("prepStmtCacheSqlLimit", env.getProperty(prefix + "hikari.data-source-properties.prepStmtCacheSqlLimit"));
		config.addDataSourceProperty("useServerPrepStmts", env.getProperty(prefix + "hikari.data-source-properties.useServerPrepStmts"));

		HikariDataSource dataSource = new HikariDataSource(config);

		return dataSource;
	}

	@Bean(name = "andongEntityManager2")
	// @Primary
	public LocalContainerEntityManagerFactoryBean andongEntityManager2() {
		// log.info("LocalContainerEntityManagerFactoryBean");
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(dbMallDataSource2());
		em.setPackagesToScan(new String[] { "co.kr.smartplusteam.luna.study.vo" });

		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);

		Map<String, Object> jpaProperties = new HashMap<>();
		em.setJpaPropertyMap(jpaProperties);
		return em;
	}

	@Bean(name = "andongTransactionManager2")
	// @Primary
	public PlatformTransactionManager dbMallTransactionManager2() {
		// log.info("dbMallTransactionManager");

		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(andongEntityManager2().getObject());

		return transactionManager;
	}

	@Bean(name = "hikari2")
	// @Primary
	public HikariDataSource dbMallDataSource2() {
		// log.info("dbMallDataSource");

		HikariConfig config = new HikariConfig();

		config.setJdbcUrl(env.getProperty(prefix + "url"));
		config.setUsername(env.getProperty(prefix + "username"));
		config.setPassword(env.getProperty(prefix + "password"));
		config.setMaxLifetime(Long.parseLong(env.getProperty(prefix + "hikari.max-lifetime")));
		config.setConnectionTimeout(Long.parseLong(env.getProperty(prefix + "hikari.connection-timeout")));
		config.setValidationTimeout(Long.parseLong(env.getProperty(prefix + "hikari.validation-timeout")));
		config.addDataSourceProperty("cachePrepStmts", env.getProperty(prefix + "hikari.data-source-properties.cachePrepStmts"));
		config.addDataSourceProperty("prepStmtCacheSize", env.getProperty(prefix + "hikari.data-source-properties.prepStmtCacheSize"));
		config.addDataSourceProperty("prepStmtCacheSqlLimit", env.getProperty(prefix + "hikari.data-source-properties.prepStmtCacheSqlLimit"));
		config.addDataSourceProperty("useServerPrepStmts", env.getProperty(prefix + "hikari.data-source-properties.useServerPrepStmts"));

		HikariDataSource dataSource = new HikariDataSource(config);

		return dataSource;
	}

}
