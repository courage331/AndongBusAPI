package co.kr.smartplusteam.luna.study.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

import co.kr.smartplusteam.luna.study.vo.AndongBus;

//원문 그대로의 데이터를 저장히기 위한 elasticsearch용 
@Repository("andongRepository")
public interface AndongRepository extends ElasticsearchRepository<AndongBus, String> {

}
