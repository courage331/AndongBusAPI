package co.kr.smartplusteam.luna.study.vo;

import java.util.ArrayList;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

import com.google.gson.annotations.SerializedName;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//파싱하기전의 object 
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Document(indexName = "andong", type = "_doc") // elasticsearch용... db 이름이 andong, table 이름이 _doc 이라고 생각하는게 편하다
public class AndongBus {
	@Id
	String id;

	@SerializedName("code")
	String code;

	@SerializedName("parameter")
	AndongstationId parameter;
	// String stationId -> not json array
	String count;
	String description;
	String type;

	@SerializedName("results")
	ArrayList<AndongBusInfo> results;

}
