package co.kr.smartplusteam.luna.study.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import co.kr.smartplusteam.luna.study.service.AndongService;
import co.kr.smartplusteam.luna.study.vo.AndongBus;
import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/apitest")
public class AndongController {

	@Autowired
	private Gson gson;

	@Autowired
	AndongService andongservice;

	@RequestMapping(method = RequestMethod.GET, value = "/{stationId}", produces = MediaType.TEXT_PLAIN_VALUE)
	@ApiOperation(value = "StationId로 검색 기능", notes = "stationId 값으로 370000001~370000999까지 가능", httpMethod = "GET", produces = "application/json", consumes = "application/json")
	// value -> 어떤 건지 설명을 해준다.
	// tags -> 따로 분류를 묶을 수 있다.
	// notes -> 펼치면 세부적으로 설명을 해준다.
	public String callAPI(@PathVariable("stationId") String stationId) {

		String data = "";
		AndongBus andongBus;

		try {
			data = andongservice.search("http://bus.andong.go.kr:8080/api/facilities/station/getBusArriveData?stationId=", stationId);

			// "200".equals(200);

			andongBus = gson.fromJson(data, AndongBus.class); // json -> object

			if (andongBus.getCode().equals("200")) {
				// 성공

				// elastic search -> data 넣어줘야한다. //ID값은 랜덤으로 생성한다.
				// UUID는 Universally Unique IDentifier의 약어이고 범용 고유 식별자이다...
				// 총 36개 문자(32개 문자와 4개의 하이픈)
				// 8–4–4–4–12라는 5개의 그룹을 ‘-’ (하이픈) 으로 구분
//				andongservice.save(andongBus.builder().id(UUID.randomUUID().toString()).code(andongBus.getCode()).parameter(andongBus.getParameter())
//						.count(andongBus.getCount()).type(andongBus.getType()).description(andongBus.getDescription()).results(andongBus.getResults())
//
//
//						.build());

				// redis (parameter를 key값으로, data값을 value로 넣어준다)
				andongservice.rsave(String.valueOf(andongBus.getParameter()), data);

				// kafka
				andongservice.send(data);

				// mysql
				andongservice.mysave(andongBus);

			} else {
				// 몽고 디비 저장
				// System.out.println("에러");
				andongservice.msave(andongBus.getCode(), andongBus.getDescription());
			}

		} catch (Exception e) {
			andongservice.msave("java-error", e.getMessage());
			e.printStackTrace();
		}

		return data;
	}

	// 검색 url
	@RequestMapping(method = RequestMethod.GET, value = "/search/{stationId}")
	@ApiOperation(value = "DB에 있는 StationId값 확인  ")
	public String searchAPI(@PathVariable("stationId") String stationId) {

		String result = "";

		try {
			// 메디스에서 먼저 검색을 한다.
			if (!andongservice.rsearch(stationId).equals("false")) {

				result = "from redis<br><br>" + andongservice.rsearch(stationId);

			}
			// 메디스에 값이 없으면 mysql에서 찾는다.
			else {
				// mysql 에 있다면 검샥결과를 return
				if (!andongservice.mysearch(stationId).equals("false")) {
					result = "from-mysql<br><br>" + andongservice.mysearch(stationId);
					// 검색 결과가 없다면, 검색 결과가 없다고 알려준다.
					// redis 태우
				} else {

					result = "검색 결과가 없습니다.";
				}

			}

		} catch (Exception e) {
			andongservice.msave("java-error", e.getMessage());
			e.printStackTrace();
		}

		return result;
	}

	// routeId로 검색
	@RequestMapping(method = RequestMethod.GET, value = "/searchone/{stationId}/{routeId}")
	@ApiOperation(value = "DB에 있는 StationId,routeId값 확인  ")
	public String searchRouteId(@PathVariable("stationId") String stationId, @PathVariable("routeId") String routeId) {

		String result = "";

		result = andongservice.routesearch(stationId, routeId);

		return result;
	}

}
