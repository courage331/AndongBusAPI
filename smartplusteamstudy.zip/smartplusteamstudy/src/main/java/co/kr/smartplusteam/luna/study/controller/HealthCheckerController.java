package co.kr.smartplusteam.luna.study.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/health")
public class HealthCheckerController {

	@RequestMapping(value = "/checker", method = RequestMethod.GET)
	@ResponseBody
	public String checker() {
		String result = "Success";
		return result;
	}
}
