package co.kr.smartplusteam.luna.study.vo;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//mongodb에 aritcles라는 이름으로 적재된다.

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "articles") // collection의 이름은 articles이고 이안에 document들이 쌓인다. db > collection > document > <key, value>
public class ErrorCode {

	@Field("code")
	private String code;

	@Field("content")
	private String content;

}
