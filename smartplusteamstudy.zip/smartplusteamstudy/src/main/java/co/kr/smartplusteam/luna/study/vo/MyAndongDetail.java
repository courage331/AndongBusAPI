package co.kr.smartplusteam.luna.study.vo;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//복합키인 EmpId 사용, result 의 원소들을 row 하나씩 저장    

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "bus_tb")
public class MyAndongDetail {

	@EmbeddedId
	EmpId empId;

	@Column(name = "routeNum")
	String routeNum;

	@Column(name = "routeNm")
	String routeNm;

	@Column(name = "via")
	String via;

	@Column(name = "stationOrd")
	String stationOrd;

	@Column(name = "arrVehId")
	String arrvVehId;

	@Column(name = "plateNo")
	String plateNo;

	@Column(name = "postPlateNo")
	String postPlateNo;

	@Column(name = "predictTm")
	String predictTm;

	@Column(name = "remainStation")
	String remainStation;

	@Column(name = "govCd")
	String govCd;

	@Column(name = "govCdNm")
	String govCdNm;

}
