package co.kr.smartplusteam.luna.study.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/es")
public class ElasticSearchContoller {

	@RequestMapping(value = "/save")
	public void callSave() {

		System.out.println("elasticsearch hello");

	}
}
