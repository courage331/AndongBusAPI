package co.kr.smartplusteam.luna.study.vo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;

//복합키로 사용하기 위해서 만듬  

@Data
@Embeddable // 복합 기본키 표시
public class EmpId implements Serializable {

	@Column(name = "parameter")
	String parameter;

	@Column(name = "routeId")
	String routeId;

}
