package co.kr.smartplusteam.luna.study.vo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//mysql에 stationId를 쉽게 찾기위해서 stationId와 등록시간만저장    

@Getter
@Setter
@NoArgsConstructor
@ToString
@Entity
@Table(name = "andong_tb") // 실제 db의 테이블과 매칭될 클래스임을 명시한다.
public class MyAndongBus {

	@Id
	@Column(name = "parameter")
	String parameter;

	@Column(name = "reg_date")
	String reg_date;

}
