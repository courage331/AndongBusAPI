package co.kr.smartplusteam.luna.study.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import co.kr.smartplusteam.luna.study.vo.EmpId;
import co.kr.smartplusteam.luna.study.vo.MyAndongDetail;

//stationId와 routeId를 복합키로 가지는 result값들을 저장하기위한 repository
@Repository
public interface DetailRepository extends JpaRepository<MyAndongDetail, EmpId> {

	@Transactional // 메소드 내에서 Exception이 발생하면 해당 메소드에서 이루어진 db작업을 롤백한다.
	@Query(value = "select * from bus_tb " + "where parameter = :stationId ", nativeQuery = true) // :를 기준으로 parameter 표시
	List<String> findByParameter(@Param("stationId") String stationId);

	/*
	 * nativequery를 사용할 수 있다는 뜻이다.
	 *
	 * Native Query는 Repository에서 @Query(value=“쿼리문”, nativeQuery = true)로 수행한다.
	 * 
	 * JPA는 SQL이 지원하는 대부분의 문법과 SQL 함수들을 지원하지만 특정 데이터베이스에 종속적인 기능은 잘 지원하지 않는다. 하지만 때론 특정 데이터베이스에 종속적인 기능이 필요할 수도 있다. 다양한 이유로 JPQL을 사용할 수 없을 때, JPA는
	 * SQL을 직접 사용할 수 있는 기능을 제공하는데 이것을 네이티브 SQL(네이티브쿼리)라고 한다. 즉, 사용자가 직접 데이터베이스에 날리는 쿼리를 작성하는 것이다. 그렇다면 JPA가 지원하는 네이티브 SQL과 JDBC API를 직접 사용하는 것에는 어떤
	 * 차이가 있냐? 그것은 바로 네이트브 쿼리는 엔티티를 조회할 수 있고 JPA가 지원하는 영속성 컨텍스트의 기능을 그대로 사용할 수 있다는 것이다!
	 * 
	 * 
	 */

	@Transactional // 메소드 내에서 Exception이 발생하면 해당 메소드에서 이루어진 db작업을 롤백한다.
	@Query(value = "select * from bus_tb " + "where parameter = :stationId and routeId =:routeId", nativeQuery = true) // :를 기준으로 parameter 표시
	List<String> findByRouteId(@Param("stationId") String stationId, @Param("routeId") String routeId);
}
