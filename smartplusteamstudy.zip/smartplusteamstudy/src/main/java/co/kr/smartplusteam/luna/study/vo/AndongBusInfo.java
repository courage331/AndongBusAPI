package co.kr.smartplusteam.luna.study.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//result에 해당하는 부분   

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class AndongBusInfo {

	String routeId;
	String routeNum;
	String routeNm;
	String via;
	String stationOrd;
	String arrvVehId;
	String plateNo;
	String postPlateNo;
	String predictTm;
	String remainStation;
	String govCd;
	String govCdNm;
}
