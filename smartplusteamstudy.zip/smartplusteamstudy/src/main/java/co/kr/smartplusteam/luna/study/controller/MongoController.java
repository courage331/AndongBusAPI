package co.kr.smartplusteam.luna.study.controller;

import javax.annotation.Resource;

import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/mongo")
public class MongoController {

	@Resource
	MongoTemplate mongoTemplate;

//	@RequestMapping(value = "/checker", method = RequestMethod.GET)
//	@ResponseBody
//	public Object checker() {
//
//		//Test test = new Test();
//		test.setLogDate(new Date());
//		test.setNameTest("테스트 테스트");
//		mongoTemplate.insert(test);
//
//		return test;
//	}
}
