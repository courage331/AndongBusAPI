package co.kr.smartplusteam.luna.study.controller;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import co.kr.smartplusteam.luna.study.service.KafkaProducerService;

@RestController
@RequestMapping(value = "/kafka")
public class KafkaProductController {

	@Resource
	KafkaProducerService kafkaProducerService;

	@RequestMapping(value = "/checker", method = RequestMethod.GET)
	public Object checker() {

		kafkaProducerService.sendTopic("juntae-topic", "이거는 데이터");

		return "성공했다";

	}
}
