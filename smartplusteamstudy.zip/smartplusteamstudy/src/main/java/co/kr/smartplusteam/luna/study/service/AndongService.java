package co.kr.smartplusteam.luna.study.service;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;

import co.kr.smartplusteam.luna.study.repository.AndongRepository;
import co.kr.smartplusteam.luna.study.repository.BusRepository;
import co.kr.smartplusteam.luna.study.repository.DetailRepository;
import co.kr.smartplusteam.luna.study.vo.AndongBus;
import co.kr.smartplusteam.luna.study.vo.AndongBusInfo;
import co.kr.smartplusteam.luna.study.vo.EmpId;
import co.kr.smartplusteam.luna.study.vo.ErrorCode;
import co.kr.smartplusteam.luna.study.vo.MyAndongBus;
import co.kr.smartplusteam.luna.study.vo.MyAndongDetail;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AndongService {

	@Autowired
	private Gson gson;

	private RestTemplate restTemplate = new RestTemplate();

	@Resource
	MongoTemplate mongoTemplate;

	@Resource
	KafkaProducerService kafkaProducerService;

	// elasticsearch
	@Autowired
	@Resource(name = "andongRepository")
	private AndongRepository andongrepository;

	// jpa, mysql
	@Resource
	private BusRepository busRepository;

	@Resource
	private DetailRepository detailRepository;

	@Autowired
	@Resource(name = "red")
	RedisTemplate<String, String> redisTemplate;

	public String search(String url, String stationId) {

		String data = restTemplate.getForObject(
				URI.create("http://bus.andong.go.kr:8080/api/facilities/station/getBusArriveData?stationId=" + stationId), String.class);

		return data;
	}

	// mongodb 저장
	public void msave(String code, String content) {
		ErrorCode errcode = new ErrorCode();
		errcode.setCode(code);
		errcode.setContent(content);
		mongoTemplate.insert(errcode);
//		System.out.println("MongoDB 성공   ");
		log.info("MongoDB Success");
	}

	// redis 저장
	public void rsave(String key, String value) {
		// redis에 10분동안 지속 되는 key, value를 넣는다.
		// 중복된 key가 들어갈 경우 가장 최근의 value로 업데이트 된다.
		redisTemplate.opsForValue().set(key, value, 10, TimeUnit.MINUTES);
//		System.out.println("redis 성공    ");
		log.info("Redis Success");
	}

	// elastic search로 저장
	public void save(AndongBus info) {
		andongrepository.save(info); // 원무 그대로 저장
//		System.out.println("elasticsearch 성공    ");
		log.info("ElasticSearch Success");
	}

	// kafka
	public void send(String data) {
		kafkaProducerService.sendTopic("steve", data); // steve 가 topic!!!!
//		System.out.println("kafka 성공");
		log.info("kafka Success");
	}

	// mysql
	public void mysave(AndongBus andongbus) {
		// 저장한 시간
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date today = new Date();

		// andongbus의 result 결과값들이 담기는 arraylist이다...
		ArrayList<AndongBusInfo> parsing = andongbus.getResults();

		MyAndongBus dataStorage = new MyAndongBus();

		dataStorage.setParameter(String.valueOf(andongbus.getParameter()));
		dataStorage.setReg_date(format1.format(today));
		busRepository.save(dataStorage);
		for (int i = 0; i < parsing.size(); i++) {

			MyAndongDetail dataStorage2 = new MyAndongDetail();
			// 복합키
			EmpId empId = new EmpId();
			empId.setParameter(String.valueOf(andongbus.getParameter()));
			empId.setRouteId(parsing.get(i).getRouteId());

			dataStorage2.setEmpId(empId);
			dataStorage2.setRouteNum(parsing.get(i).getRouteNum());
			dataStorage2.setRouteNm(parsing.get(i).getRouteNm());
			dataStorage2.setVia(parsing.get(i).getVia());
			dataStorage2.setStationOrd(parsing.get(i).getStationOrd());
			dataStorage2.setArrvVehId(parsing.get(i).getArrvVehId());
			dataStorage2.setPlateNo(parsing.get(i).getPlateNo());
			dataStorage2.setPredictTm(parsing.get(i).getPredictTm());
			dataStorage2.setRemainStation(parsing.get(i).getRemainStation());
			dataStorage2.setGovCd(parsing.get(i).getGovCd());
			dataStorage2.setGovCdNm(parsing.get(i).getGovCdNm());

			detailRepository.save(dataStorage2);
		}

//		System.out.println("mysql 저장 성공");
		log.info("Mysql Success");
	}

	// redis search
	public String rsearch(String stationId) {
		String result = "";

		try {
			// stationId가 있을경우 그것의 value를 return한다.
			result = redisTemplate.opsForValue().get(stationId);
		} catch (Exception e) {
			// error 가 발생하면 몽고db에 적재하자.
			ErrorCode errcode = new ErrorCode();
			errcode.setCode("java-error");
			errcode.setContent(e.getMessage());
			mongoTemplate.insert(errcode);
			log.info("MongoDB 성공   ");

		}

		if (result != null) {
		} else {
			result = "false";
		}

		return result;
	}

	// mysql search
	public String mysearch(String stationId) {

		String result = "";
		try {
			List<String> lines;
			// bus repository에 해당하는 stationId 없으면 false 리턴
			// 아니면 detailRepository에서 stationId를 가지는 값들을 전부 맅천한다.
			if (String.valueOf(busRepository.findById(stationId)).equals("Optional.empty")) {
				return "false";
			}
			lines = detailRepository.findByParameter(stationId);

			// 이부분을 어떻게 하면 깔끔하게 출력할까....
			String[] info = { "StationId : ", "routeId : ", "routeNum : ", "routeNm : ", "via : ", "stationOrd : ", "arrVehid : ", "plateNo : ",
					"postPlateNo : ", "predictTm : ", "remainStation : ", "govCd : ", "govCdNm : "

			};

			for (int i = 0; i < lines.size(); i++) {

				String[] values = lines.get(i).split(",");
				for (int j = 0; j < info.length; j++) {
					result += info[j] + values[j] + "<br>";
				}
				result += "<br><br>";

			}

			return result;

		} catch (Exception e) {
			// error 가 발생하면 몽고db에 적재하자.
			ErrorCode errcode = new ErrorCode();
			errcode.setCode("java-error");
			errcode.setContent(e.getMessage());
			mongoTemplate.insert(errcode);
			log.info("MongoDB Success");
			return "false";
		}

	}

	public String routesearch(String stationId, String routeId) {
		String result = "";
		List<String> lines;
		lines = detailRepository.findByRouteId(stationId, routeId);

		String[] info = { "StationId : ", "routeId : ", "routeNum : ", "routeNm : ", "via : ", "stationOrd : ", "arrVehid : ", "plateNo : ",
				"postPlateNo : ", "predictTm : ", "remainStation : ", "govCd : ", "govCdNm : "

		};

		for (int i = 0; i < lines.size(); i++) {

			String[] values = lines.get(i).split(",");
			for (int j = 0; j < info.length; j++) {
				result += info[j] + values[j] + "<br>";
			}
			result += "<br><br>";
		}

		return result;
	}

}
