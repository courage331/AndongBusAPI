package co.kr.smartplusteam.luna.study.vo;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

//"parameter" : { "stationId" : "370000023" } 처럼 돠어 있는 값을 처리하기 위해서 사용

public class AndongstationId implements Serializable {

	String stationId;

	@Override
	public String toString() {

		return stationId;
	}
}
